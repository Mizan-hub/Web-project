$(document).ready(function(){


    $('#mobile-menu').meanmenu({
        meanScreenWidth:"991",
        meanMenuContainer:'.mobile-menu'
    });

    $('.slider-active').slick({
        infinite:true,
        slidesToShow:1,
        arrows:false,
        dots:false,
        autoplay:true,
        speed:2000,
        slidesToScroll:1
            
    });


    $('.testimonial-active').slick({
        infinite:true,
        slidesToShow:1,
        arrows:false,
        dots:true,
        autoplay:true,
        speed:2000,
        slidesToScroll:1
            
    });


    $('.brand-active').slick({
        infinite:true,
        slidesToShow:5,
        arrows:false,
        dots:false,
        autoplay:true,
        slidesToScroll:1,
        responsive: [
            { 
                breakpoint:991,
                settings:{
                    slidesToShow:4,
                    slidesToScroll:1
                }

            },
            { 
                breakpoint:767,
                settings:{
                    slidesToShow:3,
                    slidesToScroll:1
                }

            },
            { 
                breakpoint:480,
                settings:{
                    slidesToShow:2,
                    slidesToScroll:1
                }

            }
           
        ]
            
    });

  

    $('.counter').counterUp({
        delay: 10,
        time: 2000
    });

    //wow js
    new WOW().init();

    $.scrollUp({

        scrollName:'scrollUp',
        topDistance:'300',
        topSpeed:'300',
        animation:'fade',
        animationInSpeed:200,
        animationOutSpeed:200,
        scrollText:'<i class="fas fa-angle-up"></i>',
        activeOverlay:false,

    })



})